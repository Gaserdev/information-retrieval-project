
# 🎟 Eventbrite AI Recommendation System

## Features
- AI Recommendation System
- Information Retrieval Search Engine
- TF-IDF Ranking
- Cosine Similarity
- Interactive Dashboard
- EDA Visualizations
- Eventbrite Dataset Integration
- Professional GUI

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
