
import streamlit as st
import pandas as pd
import numpy as np
import re
import plotly.express as px
import plotly.graph_objects as go
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(
    page_title="Eventbrite AI Recommendation System",
    page_icon="🎟️",
    layout="wide"
)

# --------------------- STYLE ---------------------
st.markdown("""
<style>
.stApp {
    background: linear-gradient(to bottom right, #0f172a, #111827);
    color: white;
}

.block-container {
    padding-top: 2rem;
}

.card {
    background-color: rgba(255,255,255,0.05);
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 20px;
    backdrop-filter: blur(10px);
}

.title-text {
    font-size: 50px;
    font-weight: bold;
    text-align: center;
}

.subtitle {
    text-align: center;
    color: #cbd5e1;
    margin-bottom: 30px;
}

.metric-card {
    background-color: rgba(255,255,255,0.04);
    border-radius: 15px;
    padding: 20px;
    text-align: center;
}
</style>
""", unsafe_allow_html=True)

# --------------------- DATA ---------------------
@st.cache_data
def load_data():
    try:
        return pd.read_csv("processed_eventbrite_dataset.csv")
    except:
        data = {
            "title": [
                "AI Conference",
                "Music Festival",
                "Cyber Security Summit",
                "Startup Meetup",
                "Yoga Workshop",
                "Machine Learning Bootcamp"
            ],
            "category": [
                "Technology",
                "Entertainment",
                "Technology",
                "Business",
                "Health",
                "Technology"
            ],
            "location": [
                "Cairo",
                "Giza",
                "Alexandria",
                "Dubai",
                "Cairo",
                "Riyadh"
            ],
            "description": [
                "Artificial intelligence conference and networking.",
                "Music performances and entertainment activities.",
                "Ethical hacking and cyber security training.",
                "Entrepreneurship and startup networking event.",
                "Yoga meditation wellness activities.",
                "Machine learning and deep learning workshop."
            ]
        }
        return pd.DataFrame(data)

df = load_data()

if "clean_description" not in df.columns:
    df["clean_description"] = (
        df["description"]
        .astype(str)
        .str.lower()
        .apply(lambda x: re.sub(r"[^a-zA-Z\\s]", "", x))
    )

# --------------------- MODEL ---------------------
vectorizer = TfidfVectorizer(max_features=1000, ngram_range=(1,2))
tfidf_matrix = vectorizer.fit_transform(df["clean_description"])

similarity_matrix = cosine_similarity(tfidf_matrix)

# --------------------- SIDEBAR ---------------------
st.sidebar.title("🎛 Navigation")

page = st.sidebar.radio(
    "Pages",
    [
        "🏠 Home",
        "📊 Dashboard",
        "🔍 Search Engine",
        "🤖 Recommendation System",
        "📚 IR Concepts",
        "🧠 AI Model",
        "👨‍💻 Team"
    ]
)

# --------------------- HOME ---------------------
if page == "🏠 Home":

    st.markdown('<div class="title-text">🎟 Eventbrite AI Recommendation System</div>', unsafe_allow_html=True)

    st.markdown(
        '<div class="subtitle">AI + Information Retrieval + Dashboard + Recommendation Engine</div>',
        unsafe_allow_html=True
    )

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Total Events", len(df))

    if "category" in df.columns:
        col2.metric("Categories", df["category"].nunique())

    if "location" in df.columns:
        col3.metric("Locations", df["location"].nunique())

    col4.metric("TF-IDF Features", tfidf_matrix.shape[1])

    st.markdown("---")

    st.subheader("📄 Dataset Preview")
    st.dataframe(df.head(10), use_container_width=True)

    st.markdown("""
    ### 🚀 Project Features
    - Information Retrieval Search Engine
    - TF-IDF Ranking
    - Cosine Similarity
    - AI Recommendation System
    - Dashboard & EDA
    - Interactive GUI
    - Eventbrite Dataset Integration
    """)

# --------------------- DASHBOARD ---------------------
elif page == "📊 Dashboard":

    st.title("📊 Dashboard & EDA")

    col1, col2 = st.columns(2)

    with col1:
        category_counts = df["category"].value_counts().reset_index()
        category_counts.columns = ["Category", "Count"]

        fig = px.bar(
            category_counts,
            x="Count",
            y="Category",
            orientation="h",
            title="Events by Category"
        )

        st.plotly_chart(fig, use_container_width=True)

    with col2:
        if "location" in df.columns:
            location_counts = df["location"].value_counts().reset_index()
            location_counts.columns = ["Location", "Count"]

            pie = px.pie(
                location_counts,
                names="Location",
                values="Count",
                title="Events Distribution by Location"
            )

            st.plotly_chart(pie, use_container_width=True)

    df["description_length"] = df["clean_description"].astype(str).apply(len)

    hist = px.histogram(
        df,
        x="description_length",
        nbins=20,
        title="Description Length Distribution"
    )

    st.plotly_chart(hist, use_container_width=True)

# --------------------- SEARCH ---------------------
elif page == "🔍 Search Engine":

    st.title("🔍 Information Retrieval Search Engine")

    query = st.text_input("Search events using keywords")

    if query:

        query_vector = vectorizer.transform([query])

        scores = cosine_similarity(query_vector, tfidf_matrix).flatten()

        top_indices = scores.argsort()[::-1][:5]

        results = df.iloc[top_indices].copy()

        results["Similarity Score"] = scores[top_indices]

        st.subheader("🎯 Top Matching Results")

        st.dataframe(
            results[
                ["title", "category", "location", "Similarity Score"]
            ],
            use_container_width=True
        )

# --------------------- RECOMMENDATION ---------------------
elif page == "🤖 Recommendation System":

    st.title("🤖 AI Recommendation System")

    selected_event = st.selectbox(
        "Choose an Event",
        df["title"].tolist()
    )

    idx = df[df["title"] == selected_event].index[0]

    scores = list(enumerate(similarity_matrix[idx]))

    scores = sorted(scores, key=lambda x: x[1], reverse=True)

    recommended = scores[1:6]

    recommendations = []

    for i in recommended:
        recommendations.append({
            "Event": df.iloc[i[0]]["title"],
            "Category": df.iloc[i[0]]["category"],
            "Location": df.iloc[i[0]]["location"],
            "Similarity": round(i[1], 3)
        })

    recommendations = pd.DataFrame(recommendations)

    st.dataframe(recommendations, use_container_width=True)

# --------------------- IR ---------------------
elif page == "📚 IR Concepts":

    st.title("📚 Information Retrieval Concepts")

    st.markdown("""
    ## Implemented Concepts

    ### ✅ Indexing
    Building searchable representations for events.

    ### ✅ TF-IDF
    Ranking important terms inside event descriptions.

    ### ✅ Cosine Similarity
    Measuring similarity between documents/events.

    ### ✅ Search & Ranking
    Returning the most relevant events to user queries.

    ### ✅ Keyword Matching
    User search queries compared against event descriptions.
    """)

# --------------------- AI ---------------------
elif page == "🧠 AI Model":

    st.title("🧠 AI Workflow")

    workflow = pd.DataFrame({
        "Step": [
            "Data Collection",
            "Data Cleaning",
            "Preprocessing",
            "TF-IDF",
            "Similarity Matrix",
            "Recommendation",
            "Dashboard"
        ],
        "Progress": [100,100,100,100,100,100,100]
    })

    line = px.line(
        workflow,
        x="Step",
        y="Progress",
        markers=True,
        title="Project Workflow"
    )

    st.plotly_chart(line, use_container_width=True)

    st.markdown("""
    ### AI Techniques Used
    - Recommendation System
    - Natural Language Processing
    - Text Vectorization
    - Similarity Analysis
    - Information Retrieval
    """)

# --------------------- TEAM ---------------------
elif page == "👨‍💻 Team":

    st.title("👨‍💻 Project Team")

    st.markdown("""
    ### Team Members
    - Gasser Ahmed
    - Shahd Fawzy
    - Nourhan Diaa
    - Safaa Khalil

    ### Dataset Source
    Eventbrite Website

    ### Technologies
    - Python
    - Streamlit
    - Scikit-learn
    - Plotly
    - Machine Learning
    - Information Retrieval
    """)

st.markdown("---")
st.caption("Built with Streamlit • Eventbrite Dataset • AI & Information Retrieval")
